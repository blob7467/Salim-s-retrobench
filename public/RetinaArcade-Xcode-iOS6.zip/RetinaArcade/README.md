# Retina Arcade - Native iPhone 4 / iOS 6 Project
Target Architecture: armv7 (Apple A4 Cortex-A8, PowerVR SGX535)
Target Firmware: iOS 4.3 through iOS 6.1.6
Screen Resolution: 640x960 Retina Display (326 ppi)

## Contents:
- main.m: Native application entry point
- AppDelegate.m / .h: Application lifecycle and window setup
- ArcadeViewController.m / .h: Springboard UI and game dispatcher
- BladeFruitView.m / .h: Native CADisplayLink 60FPS fruit slicing game
- DoodleLeapView.m / .h: Native CoreMotion accelerometer tilt jumper
- LabyrinthView.m / .h: Native 3-Axis Gyroscope marble physics
- SoundManager.m / .h: AudioToolbox skeuomorphic sound effects
- RetinaArcade.xcodeproj: Complete Xcode 4 / 5 project

## How to Build:
1. Open RetinaArcade.xcodeproj in Xcode 4.6 (OS X Mountain Lion) or Xcode with iOS 6 SDK.
2. Select "iOS Device" or "iPhone 4" as scheme.
3. Build & Run (Product -> Build).
4. Sideload via Sideloadly, 3uTools, Xcode Organizer, or AppSync Unified.
